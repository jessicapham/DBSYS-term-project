/**
 * Specialized graph implementations using sparse matrix representations.
 */
package org.jgrapht.opt.graph.sparse;
