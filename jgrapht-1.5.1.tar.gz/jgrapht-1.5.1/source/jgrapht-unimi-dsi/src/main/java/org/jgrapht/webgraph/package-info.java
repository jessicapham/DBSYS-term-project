/**
 * Adapters for graphs stored using
 * <a href="http://webgraph.di.unimi.it/">WebGraph</a>'s compressed and succinct
 * formats.
 */
package org.jgrapht.webgraph;
